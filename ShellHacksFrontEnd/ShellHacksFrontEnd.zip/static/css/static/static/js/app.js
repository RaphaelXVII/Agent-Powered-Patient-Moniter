// Global variables
let currentUser = null;
const loginForm = document.getElementById('login-form');
const userInfo = document.getElementById('user-info');
const currentUserSpan = document.getElementById('current-user');

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    // Check if we're on the patients page
    if (window.location.pathname === '/patients') {
        loadPatients();
        setupPatientEventListeners();
    } else {
        // Just show login form for home page
        showLoginForm();
    }
});

// Login functionality
function handleLogin() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    
    if (!username || !password) {
        alert('Please enter both username and password');
        return;
    }
    
    // Simple demo login
    if (username === 'admin' && password === 'password') {
        currentUser = username;
        // Redirect to patients page instead of showing alert
        window.location.href = '/patients';
    } else {
        alert('Invalid username or password. Try: admin/password');
    }
}

function handleLogout() {
    currentUser = null;
    // Redirect back to login page
    window.location.href = '/';
}

function showUserInfo() {
    loginForm.style.display = 'none';
    userInfo.style.display = 'flex';
    currentUserSpan.textContent = currentUser;
}

function showLoginForm() {
    loginForm.style.display = 'flex';
    userInfo.style.display = 'none';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}

// Patient management functions
function setupPatientEventListeners() {
    // Add search functionality
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('input', handleSearch);
    }
    const floorSelect = document.getElementById('floor-select');
    if (floorSelect) {
        floorSelect.addEventListener('change', handleFloorFilter);
    }
}

// Load patients data
async function loadPatients() {
    try {
        const response = await fetch('/api/patients');
        if (response.ok) {
            const patients = await response.json();
            window.allPatients = patients;
            renderPatients(patients);
        }
    } catch (error) {
        console.error('Error loading patients:', error);
    }
}

// Render patients on the page
function renderPatients(patients) {
    const container = document.getElementById('patients-container');
    
    if (patients.length === 0) {
        container.innerHTML = '<div class="empty-state"><h3>No patients found</h3></div>';
        return;
    }
    
    const patientsHTML = patients.map(patient => `
        <div class="patient-card">
            <div class="patient-info">
                <div class="patient-name">${patient.name}</div>
                <div class="patient-details">
                    Age: ${patient.age} | Condition: ${patient.condition} | Last Visit: ${patient.last_visit} | Floor: ${patient.floor}
                </div>
                <div class="ventilation-data">
                    <span>Respiratory Rate: ${patient.respiratory_rate} bpm</span>
                    <span>Airflow: ${patient.airflow}%</span>
                </div>
            </div>
            <div class="patient-id">${patient.id}</div>
            <div class="patient-actions">
                <button class="btn-view" onclick="viewPatient('${patient.id}')">View</button>
            </div>
        </div>
    `).join('');
    
    container.innerHTML = patientsHTML;
}

// Patient action functions
function viewPatient(patientId) {
    // Redirect to patient detail page
    window.location.href = `/patient/${patientId}`;
}


function handleSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    // You can implement search logic here
    console.log('Searching for:', searchTerm);
}


function handleFloorFilter(event) {
    const selectedFloor = event.target.value;
    filterPatientsByFloor(selectedFloor);
}

function filterPatientsByFloor(floor) {
    // Get all patients from the current page
    const allPatients = window.allPatients || [];
    
    if (floor === 'all') {
        renderPatients(allPatients);
    } else {
        const filteredPatients = allPatients.filter(patient => patient.floor == floor);
        renderPatients(filteredPatients);
    }
}
